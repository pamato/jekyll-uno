---
title: "Introduction to Social Network Analysis - Lab 1"
author: "Paulo Serôdio"
output:
  html_document:
    theme: paper
    toc: yes
    code_folding: show
    df_print: kable
    toc_float: 
      collapsed: false
    

---


Start from clean slate and free up memory

```{r tidy=TRUE, results=FALSE}
rm(list = ls())
gc()
```

Load R packages

```{r tidy=TRUE, results=FALSE, message=FALSE}
packages <- c("statnet", "igraph", "RSiena", "EpiModel", "kableExtra", "netdiffuseR", "sna", "ergm", "coda", "lattice", "plyr", "dplyr", "tidyr", "magrittr","mosaic", "snatools", "tidyverse", "ggplot2", "ggnetwork", "visNetwork", "GGally", "ggraph", "networkD3", "ndtv", "amen", "knitr", "rio")
missing.packages <- which(!packages %in% installed.packages()[,"Package"])
if(length(missing.packages)) install.packages(packages[missing.packages])
#lapply(packages, require, character.only=T)
library(tidyverse)
```

# Handing Network Data


## Matrix Operations

Creating matrix

```{r}
m <- matrix(data=1, nrow=5, ncol=4)
dim(m)
m <- matrix(1:10,10,10)
```

Select matrix elements: 

```{r, tidy=TRUE}
m[2,3]  # Matrix m, row 2, column 3 - a single cell
m[2,]   # The whole second row of m as a vector
m[,2]   # The whole second column of m as a vector
m[1:2,4:6] # submatrix: rows 1 and 2, columns 4, 5 and 6
m[-1,]     # all rows *except* the first one
```

Import Camp data: 
  - these data were collected by Steve Borgatti, Russ Bernard, Bert Pelto and Gery Ryan at the 1992 NSF Summer Institute on Research Methods in Cultural Anthropology. This was a 3 week course given to 14 carefully selected participants. Network data were collected at the end of each week. These data were collected at the end of the second week. The data were collected by placing each person's name on a card and asking each respondent to sort the cards in order of how much interaction they had with that person since the beginning of the course (known informally as "camp"). This results in rank order data in which a "1" indicates the most interaction while a "17" indicates the least interaction.

```{r}
camp92 <- as.matrix(rio::import("./data/camp92.txt"))[,-1]
camp92 <- apply(camp92, 2, as.numeric)
rownames(camp92) <- colnames(camp92)
```

Transpose matrix:

```{r, tidy=TRUE}
print(camp92)
t(camp92)
```

## Dichotomizing (thinning network)

```{r, tidy=TRUE}
campnet <- ifelse(camp92>5, 1, 0)
print(campnet)
```

## Transposing and multiplying networks multiplication 

```{r, tidy=TRUE}
# Transposing
t(campnet)

# Matrix multiplication as sum of vector dot-products
campnet %*% campnet    # Multiplying adjacency matrix by itself (A^2). Result? A_ij shows # 2-length paths. Diagonal shows degree of node i. E.g. Calculate entry A_21 and soon realise we're checking for presence of 1s in both second row (Brazey's out-ties) and first column (Holly's in-ties), which is a directed two-path from Brazey to Holly.
print(campnet)
campnet %*% t(campnet)    # Multiplying by its transpose, what do we get? Ties in common.
```

```{r tidy=TRUE}
# Element-wise multiplication (both matrices must have same dimension)
campnet * t(campnet)         # Note that * is element-wise multiplication. What do we get? Symmetric Adjacency Matrix under the max/strong rule.
```

## Symmetrizing

```{r, tidy=TRUE}
sna::symmetrize(campnet, rule="weak") # OR rule, if either i->j or i<-j exist;
sna::symmetrize(campnet, rule="strong") # AND rule, iff i<->j exist;
sna::symmetrize(campnet, rule="upper") # copy the upper triangle over the lower;
sna::symmetrize(campnet, rule="lower") # copy the lower triangle over the upper;
```


## Network Modes

Brief intro to dataset: "The National Longitudinal Study of Adolescent to Adult Health (**Add Health**) is a longitudinal study of a nationally representative sample of adolescents in grades 7-12 in the United States during the 1994-95 school year. Add Health combines longitudinal survey data on respondents’ social, economic, psychological and physical well-being with contextual data on the family, neighborhood, community, school, friendships, peer groups, and romantic relationships, providing unique opportunities to study how social environments and behaviors in adolescence are linked to health and achievement outcomes in young adulthood." 

Tidyverse grammar:
    - Selecting: always refers to selecting the columns you want.
    - Arranging: reorder rows with respect to columns. 
    - Mutating: refers to creating a new variable based on operations peformed on another variable.
    - Filtering: refers to filtering by rows
    - Renaming: refers to relabeling column names.
    - Gathering: refers to gathering columns to transform a wide data set into a long one.
    - Summarizing: refers to generating summary statitics for a given variable.
    - Separating: refers to splitting delimited values in one column into multiple columns
    - Distinct: Eliminates all duplicate values 
    - Joining: refers to merging data sets using key variable.


* Import and arrange AddHealth data

```{r}
AHS_WPVAR <- rio::import('./data/ahs_wpvar.csv')
```

```{r, echo=FALSE}
kableExtra::kable(head(AHS_WPVAR[,c(1:13)])) %>%
  kableExtra::kable_styling(bootstrap_options = c("striped", "hover", "condensed", "responsive", full_width = FALSE))
```

**mf** stands for "male friend"; **ff** female friend; **mfact** stands for # of acts;

- Transform data wide to long as to capture all ties between Ego and Alters. Alters currently organised in different columns. Two variables: tie and frequency of interaction (number of acts).

```{r}
AHS_Edges <- AHS_WPVAR %>%
      select(ego_nid, mfnid_1:mfnid_5, ffnid_1:ffnid_5, commcnt, sex) %>% 
      filter(commcnt == 7) %>%
      gather(Alter_Label, value, mfnid_1:mfnid_5, ffnid_1:ffnid_5, na.rm = TRUE) %>% 
      arrange(ego_nid, sex) %>% 
      filter(value != 99999) %>%
      select(ego_nid, value) %>%  
      rename(Sender = `ego_nid`, Target = `value`)     
```

- Creating nodelist

```{r results=FALSE}
AHS_Nodes <- AHS_Edges %>% 
  gather(Alter_Label, value, Sender, Target, na.rm = TRUE) %>%
  select(value) %>% rename(ego_nid = `value`)
  AHS_Nodes <- AHS_Nodes %>% distinct(ego_nid)
  
AHS_Nodes <- AHS_Nodes %>% (add_rownames) %>% rename (Sender_ID = rowname) %>%
                mutate(Sender_ID = as.numeric(Sender_ID)) 
```

- Merging/Joining Numeric IDs into the Edgelist

```{r}
AHS_Nodes <- AHS_Nodes %>% rename(Sender = `ego_nid`)
AHS_Edges <- AHS_Edges %>% left_join(AHS_Nodes, by = c("Sender"))
AHS_Nodes <- AHS_Nodes %>% rename(Target = `Sender`, Target_ID = `Sender_ID`)
AHS_Edges <- AHS_Edges %>% left_join(AHS_Nodes, by = c("Target"))

```
- Tidying up edgelists and nodelists

```{r}
AHS_Edges <- AHS_Edges %>%
  select(Sender_ID, Target_ID)  %>%
  rename(Sender = `Sender_ID`, Target = `Target_ID`)

AHS_Nodes <- AHS_Nodes %>%
  rename (ego_nid = `Target`, ID = `Target_ID`)
```

- Adding attributes

```{r}
AHS_Attributes <- AHS_WPVAR %>%
  select(commcnt, ego_nid, sex, grade, race5) %>%
  filter(commcnt == 7)

AHS_Nodes <- AHS_Nodes %>%
  left_join(AHS_Attributes, by = c("ego_nid"))

save(AHS_Edges,file="AHS_Edges.Rda")
save(AHS_Nodes, file="AHS_Nodes.Rda")
```

### One-mode network

From an edgelist

```{r}
print(AHS_Edges[1:20,])
ahs.net <- network::network(AHS_Edges, matrix.type = "edgelist")
print(ahs.net)
  # order of the rows is different, but network is the same
```

From an adjacency matrix
```{r, tidy=TRUE}
adj.mat <- network::as.matrix.network(ahs.net)
adj.mat[1:20, 1:20]
ahs.net <- network::network(adj.mat, matrix.type = "adjacency")
print(ahs.net)
```

From a nodelist


g <- graph.adjacency(matrix, mode="directed", weighted=FALSE, diag=FALSE)


```{r}
ahs.nodelist <- NULL
for (i in unique(AHS_Edges$Sender)){
  nodelist <- unlist(strsplit(paste(c(i, AHS_Edges$Target[AHS_Edges$Sender==i]), collapse = ","), ","))
  names(nodelist) <- c("sender", paste0(rep("target", length(nodelist)-1), 1:(length(nodelist)-1)))
  ahs.nodelist <- plyr::rbind.fill(ahs.nodelist, data.frame(t(as.matrix(nodelist))))
}                    
                       
```

getwd







## Application: Multidimensional Scaling on distance data



## Network Objects






### Tips

[R Markdown](http://rmarkdown.rstudio.com)
*Run*
`install.packages("qtl")`
$\sum_{n=1}^{10} n^2$ is rendered as 

$$\sum_{n=1}^{10} n^2$$


