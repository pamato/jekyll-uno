install.packages("smacof")
install.packages("rworldmap")
install.packages("ggmap")
install.packages("googleAuthR")
library(maps)
library(googleAuthR)
library(ggmap)
library(smacof)
library(grid)
library(rworldmap)

## For USA ##

# Build dataframe for plotting map of USA
states <- map_data("state")
geo.city <-  c("Atlanta", "Boston", "Dallas", "Indianapolis", "Los Angeles", "Memphis", "St. Louis", "Spokane", "Tempa")
# Register google API key, activate Geocoding
register_google(key="AIzaSyDUdRWWmcNPkeSgYwHuzohopZNQYuHjRJI")
has_google_key()
geo.codes <- geocode(geo.city)
geo.data <- data.frame(name = geo.city, lon = geo.codes[, 1], lat = geo.codes[, 2])
geo.data$lon[geo.data$name=="Boston"] <- -71.0589
geo.data$lat[geo.data$name=="Boston"] <- 42.3601
geo.data$lon[geo.data$name=="Memphis"] <- -90.0490
geo.data$lat[geo.data$name=="Memphis"] <- 35.1495
# Plot map
usa <- data.frame(region=states$region, group=states$group, lon=states$long, lat=states$lat)
ggplot() + geom_polygon(data = usa, aes(x=lon, y=lat, group = group, fill=I("grey45"))) + 
    geom_path(color = "gray") + #coord_map(project="globular") +
    xlab("Longitude") + ylab("Latitude") +
    geom_point(data= geo.data, mapping=aes(x = geo.data$lon, y = geo.data$lat)) +
    geom_text(data=geo.data, aes(x = geo.data$lon, y = geo.data$lat, label=name),hjust=0, vjust=0)


### USA ###

states <- map_data("state")
geo.city <- rownames(as.matrix(UScitiesD))
register_google(key="AIzaSyDUdRWWmcNPkeSgYwHuzohopZNQYuHjRJI")
has_google_key()
geo.codes <- geocode(geo.city)
geo.data <- data.frame(name = geo.city, lon = geo.codes[, 1], lat = geo.codes[, 2])
usa <- data.frame(region=states$region, group=states$group, lon=states$long, lat=states$lat)
ggplot() + geom_polygon(data = usa, aes(x=lon, y=lat, group = group, fill=I("grey45"))) + 
    geom_path(color = "gray") + #coord_map(project="globular") +
    xlab("Longitude") + ylab("Latitude") +
    geom_point(data= geo.data, mapping=aes(x = geo.data$lon, y = geo.data$lat)) +
    geom_text(data=geo.data, aes(x = geo.data$lon, y = geo.data$lat, label=name),hjust=0, vjust=0)

## Distance data and MDS 

usacitydist <- as.matrix(UScitiesD)
# use smacof::mds
mds.usa <- mds(delta = usacitydist,ndim = 2, type = "ratio" )
use # stats::cmdscale
mds.usa$conf[,1] <- cmdscale(UScitiesD, k=2, eig=T)$points[,1]
mds.usa$conf[,2] <- cmdscale(UScitiesD, k=2, eig=T)$points[,2]
# Notice we need to flip the axes
ggplot() +  geom_point(data = data.frame(as.matrix(mds.usa$conf)) , mapping = aes(x = -mds.usa$conf[,1] , y = -mds.usa$conf[,2]), 
              alpha = 0.5 , color = "blue", size = 5 ) + geom_text(data = as.data.frame(as.matrix(mds.usa$conf)), 
              mapping = aes(x = -mds.usa$conf[,1] , y = -mds.usa$conf[,2]), label = rownames(mds.usa$conf) )

# Re-scale MDS coordinates by mean and std of real longitude and latitude values. Formula = yi = m2 + (xi-m1) * (s2/s1)
real.mean <- apply(geo.data[,2:3], 2, mean)
real.sd <- apply(geo.data[,2:3], 2, sd)
usacity.mds.loc <- data.frame(city = rownames(as.matrix(mds.usa$conf)), d1 = -data.frame(as.matrix(mds.usa$conf))$D1, d2 = -data.frame(as.matrix(mds.usa$conf))$D2)
usacity.mds.loc.rscaled <- usacity.mds.loc
usacity.mds.loc.rscaled$d1 <- as.numeric(real.mean[which(names(real.mean)=="lon")]) + (usacity.mds.loc.rscaled$d1-mean(usacity.mds.loc.rscaled$d1)) * ( as.numeric(real.sd[which(names(real.mean)=="lon")])/sd(usacity.mds.loc.rscaled$d1)) # rescale dimension 1 with longitude scale
usacity.mds.loc.rscaled$d2 <- as.numeric(real.mean[which(names(real.mean)=="lat")]) + (usacity.mds.loc.rscaled$d2-mean(usacity.mds.loc.rscaled$d2)) * ( as.numeric(real.sd[which(names(real.mean)=="lat")])/sd(usacity.mds.loc.rscaled$d2)) # rescale dimension 2 with latitude scale
  

# rescaled MDS map
ggplot() +  geom_point(data = usacity.mds.loc.rscaled , mapping = aes(x = usacity.mds.loc.rscaled$d1 , y = usacity.mds.loc.rscaled$d2), 
              alpha = 0.5 , color = "blue", size = 5 ) + geom_text(data = usacity.mds.loc.rscaled, 
              mapping = aes(x = usacity.mds.loc.rscaled$d1 , y = usacity.mds.loc.rscaled$d2, label = usacity.mds.loc.rscaled$city))

# Join both maps

ggplot() + geom_polygon(data = usa, aes(x = lon, y = lat, group = group, fill = I("grey45"))) + 
              geom_path(color = "gray") + xlab("Longitude") + ylab("Latitude") + #coord_map(project="globular") +
              geom_point(data = geo.data, mapping=aes(x = geo.data$lon, y = geo.data$lat)) +
              geom_text(data = geo.data, aes(x = geo.data$lon, y = geo.data$lat, label = name),hjust=0, vjust=0) +
              geom_point(data = usacity.mds.loc.rscaled , mapping = aes(x = usacity.mds.loc.rscaled$d1 , y = usacity.mds.loc.rscaled$d2), 
                alpha = 0.5 , color = "blue", size = 2 )

### Europe ###



## Map of Europe with selected cities

worldMap <- getMap()
europeanUnion <- c("Austria","Belgium","Bulgaria","Croatia","Cyprus",
                   "Czech Rep.","Denmark","Estonia","Finland","France",
                   "Germany","Greece","Hungary","Ireland","Italy","Latvia",
                   "Lithuania","Luxembourg","Malta","Netherlands","Poland",
                   "Portugal","Romania","Slovakia","Slovenia","Spain",
                   "Sweden","United Kingdom")
indEU <- which(worldMap$NAME%in%europeanUnion)
europeCoords <- lapply(indEU, function(i){
  df <- data.frame(worldMap@polygons[[i]]@Polygons[[1]]@coords)
  df$region =as.character(worldMap$NAME[i])
  colnames(df) <- list("long", "lat", "region")
  return(df)
})
europeCoords <- do.call("rbind", europeCoords)
value <- sample(x = seq(0,3,by = 0.1), size = length(europeanUnion),
                replace = TRUE)
europeanUnionTable <- data.frame(country = europeanUnion, value = value)
europeCoords$value <- europeanUnionTable$value[match(europeCoords$region,europeanUnionTable$country)]
#Plot
ggplot() + geom_polygon(data = europeCoords, aes(x = long, y = lat, group = region, fill = I("grey45")),
                             colour = "black", size = 0.1) + coord_map(xlim = c(-13, 35),  ylim = c(32, 71))
# Add European Cities based on geo-location
europcitycoord <- rio::import("/Users/pauloserodio/XenaSerodio Dropbox/Paulo Serodio/Academic/Teaching/Summer Schools & Workshops/EUI Florence 2019/day1 am/lab/european_cities_coord.xlsx")
europcitycoord$long <- as.numeric(europcitycoord$long)
ggplot() + geom_polygon(data = europeCoords, aes(x = long, y = lat, group = region, fill = I("grey45")),
                             colour = "black", size = 0.1) + coord_map(xlim = c(-13, 35),  ylim = c(32, 71)) +
          geom_point(data= europcitycoord, mapping=aes(x = europcitycoord$long, y = europcitycoord$lat)) +
          geom_text(data=europcitycoord, aes(x = europcitycoord$long, y = europcitycoord$lat, label=city), size=3, hjust=0, vjust=0)

## Distance data and MDS

europcitydist <- as.matrix(eurodist)
europcitydist <- europcitydist[-9, -9]
mds <- mds(delta = europcitydist,ndim = 2, type = "ratio" )
plot(cities_mds,caption = "Figure3: European cities MDS configuration")
ggplot() +  geom_point(data = data.frame(as.matrix(mds$conf)) , mapping = aes(x = mds$conf[,1] , y = -mds$conf[,2]), 
              alpha = 0.5 , color = "blue", size = 5 ) + geom_text(data = as.data.frame(as.matrix(mds$conf)), 
              mapping = aes(x = mds$conf[,1] , y = -mds$conf[,2]), label = rownames(mds$conf) )

# Re-scale MDS coordinates by mean and std of real longitude and latitude values. Formula = yi = m2 + (xi-m1) * (s2/s1)
real.mean <- apply(europcitycoord[,2:3], 2, mean)
real.sd <- apply(europcitycoord[,2:3], 2, sd)
city.mds.loc <- data.frame(city = rownames(as.matrix(mds$conf)), d1 = data.frame(as.matrix(mds$conf))$D1, d2 = -data.frame(as.matrix(mds$conf))$D2)
city.mds.loc.rscaled <- city.mds.loc
city.mds.loc.rscaled$d1 <- as.numeric(real.mean[2]) + (city.mds.loc.rscaled$d1-mean(city.mds.loc.rscaled$d1)) * ( as.numeric(real.sd[2])/sd(city.mds.loc.rscaled$d1)) # rescale dimension 1 with longitude scale
city.mds.loc.rscaled$d2 <- as.numeric(real.mean[1]) + (city.mds.loc.rscaled$d2-mean(city.mds.loc.rscaled$d2)) * ( as.numeric(real.sd[1])/sd(city.mds.loc.rscaled$d2)) # rescale dimension 2 with latitude scale
  
# rescaled MDS map
ggplot() +  geom_point(data = city.mds.loc.rscaled , mapping = aes(x = city.mds.loc.rscaled$d1 , y = city.mds.loc.rscaled$d2), 
              alpha = 0.5 , color = "blue", size = 5 ) + geom_text(data = city.mds.loc.rscaled, 
              mapping = aes(x = city.mds.loc.rscaled$d1 , y = city.mds.loc.rscaled$d2, label = city.mds.loc.rscaled$city))

# Join both maps

ggplot() + geom_polygon(data = europeCoords, aes(x = long, y = lat, group = region, fill = I("grey45")),
                             colour = "black", size = 0.1) + coord_map(xlim = c(-13, 35),  ylim = c(32, 71)) +
          geom_point(data= europcitycoord, mapping=aes(x = europcitycoord$long, y = europcitycoord$lat)) +
          geom_text(data=europcitycoord, aes(x = europcitycoord$long, y = europcitycoord$lat, label=city), size=3, hjust=0, vjust=0) +
          geom_point(data = city.mds.loc.rscaled , mapping = aes(x = city.mds.loc.rscaled$d1 , y = city.mds.loc.rscaled$d2), 
              alpha = 0.5 , color = "blue", size = 2 )






cmdscale(UScitiesD, k=2, eig=T)
summary(mds(delta = UScitiesD,ndim = 2, type = "ratio" ))

tolower(rownames(as.matrix(eurodist)))
europcoord <- rio::import("/Users/pauloserodio/XenaSerodio Dropbox/Paulo Serodio/Academic/Teaching/Summer Schools & Workshops/EUI Florence 2019/day1 am/lab/european_cities_coord.xlsx")
europcoord_mds <- cmdscale(dist(europeCoords[,2:3]), k=2, eig=T)
europcoord_mds <- mds(dist(europeCoords[,2:3]),ndim = 2, type = "ratio" )


europeanUnion <- c("Austria","Belgium","Bulgaria","Croatia","Cyprus",
                   "Czech Rep.","Denmark","Estonia","Finland","France",
                   "Germany","Greece","Hungary","Ireland","Italy","Latvia",
                   "Lithuania","Luxembourg","Malta","Netherlands","Poland",
                   "Portugal","Romania","Slovakia","Slovenia","Spain",
                   "Sweden","United Kingdom")
indEU <- which(worldMap$NAME%in%europeanUnion)
europeCoords <- lapply(indEU, function(i){
  df <- data.frame(worldMap@polygons[[i]]@Polygons[[1]]@coords)
  df$region =as.character(worldMap$NAME[i])
  colnames(df) <- list("long", "lat", "region")
  return(df)
})
europeCoords <- do.call("rbind", europeCoords)
europe_mds <- cmdscale(dist(europeCoords[,1:2]), k=2, eig=T)
europe_mds.df <- data.frame(europe_mds$points)
europe_mds.df$region <- europeCoords$region
colnames(europe_mds.df) <- c("long", "lat", "region")
value <- sample(x = seq(0,3,by = 0.1), size = length(europeanUnion),replace = TRUE)
europeanUnionTable <- data.frame(country = europeanUnion, value = value)
europe_mds.df$value <- europeanUnionTable$value[match(europe_mds.df$region,europeanUnionTable$country)]
ggplot() + geom_point(data = data.frame(as.matrix(europe_mds$points)) , mapping = aes(x = europe_mds$points[,1] , y = -europe_mds$points[,2]), 
              alpha = 0.5 , color = "blue", size = 5 ) + 
              labs(title = "figure3: MDS representation of pair-wise distances of European cities")
ggplot() + geom_polygon(data = europe_mds.df, aes(x = -long, y = lat, group = region, fill = value), colour = "black", size = 0.1)

## Distance data and MDS

europcitydist <- as.matrix(eurodist)
europcitydist <- europcitydist[-9, -9]
mds <- mds(delta = europcitydist,ndim = 2, type = "ratio" )
plot(cities_mds,caption = "Figure3: European cities MDS configuration")
ggplot() +  geom_point(data = data.frame(as.matrix(cities_mds$conf)) , mapping = aes(x = cities_mds$conf[,1] , y = -cities_mds$conf[,2]), 
              alpha = 0.5 , color = "blue", size = 5 ) + geom_text(data = as.data.frame(as.matrix(cities_mds$conf)), 
              mapping = aes(x = cities_mds$conf[,1] , y = -cities_mds$conf[,2]), label = rownames(cities_mds$conf) )











data(cities)
city.location[,1] <- -city.location[,1]
plot(city.location, xlab="Dimension 1", ylab="Dimension 2",
   main ="Multidimensional scaling of US cities")
city.loc <- cmdscale(cities, k=2) #ask for a 2 dimensional solution  round(city.loc,0) 
city.loc <- -city.loc 
 city.loc <- rescale(city.loc,apply(city.location,2,mean),apply(city.location,2,sd))
points(city.loc,type="n") 
text(city.loc,labels=names(cities))



data(eurodist)
data(UScitiesD)

## Europe ##

data(eurodist)
cities_mds = mds(delta = eurodist,ndim = 2, type = "ratio" )
plot(cities_mds,caption = "Figure3: European cities MDS configuration")
ggplot() +  geom_point(data = data.frame(as.matrix(cities_mds$conf)) , mapping = aes(x = cities_mds$conf[,1] , y = -cities_mds$conf[,2]), 
              alpha = 0.5 , color = "blue", size = 5 ) + geom_text(data = as.data.frame(as.matrix(cities_mds$conf)), 
              mapping = aes(x = cities_mds$conf[,1] , y = -cities_mds$conf[,2]), label = rownames(cities_mds$conf) ) + 
              labs(title = "figure3: MDS representation of pair-wise distances of European cities") +

tolower(rownames(as.matrix(eurodist)))
europcoord <- rio::import("/Users/pauloserodio/XenaSerodio Dropbox/Paulo Serodio/Academic/Teaching/Summer Schools & Workshops/EUI Florence 2019/day1 am/lab/european_cities_coord.xlsx")
europcoord_mds <- cmdscale(dist(europeCoords[,2:3]), k=2, eig=T)
europcoord_mds <- mds(dist(europeCoords[,2:3]),ndim = 2, type = "ratio" )

?dist


# superimpose map europe?
worldMap <- getMap()
europeanUnion <- c("Austria","Belgium","Bulgaria","Croatia","Cyprus",
                   "Czech Rep.","Denmark","Estonia","Finland","France",
                   "Germany","Greece","Hungary","Ireland","Italy","Latvia",
                   "Lithuania","Luxembourg","Malta","Netherlands","Poland",
                   "Portugal","Romania","Slovakia","Slovenia","Spain",
                   "Sweden","United Kingdom")
indEU <- which(worldMap$NAME%in%europeanUnion)
europeCoords <- lapply(indEU, function(i){
  df <- data.frame(worldMap@polygons[[i]]@Polygons[[1]]@coords)
  df$region =as.character(worldMap$NAME[i])
  colnames(df) <- list("long", "lat", "region")
  return(df)
})
europeCoords <- do.call("rbind", europeCoords)
europe_mds <- cmdscale(dist(europeCoords[,1:2]), k=2, eig=T)
europe_mds.df <- data.frame(europe_mds$points)
europe_mds.df$region <- europeCoords$region
colnames(europe_mds.df) <- c("long", "lat", "region")
value <- sample(x = seq(0,3,by = 0.1), size = length(europeanUnion),replace = TRUE)
europeanUnionTable <- data.frame(country = europeanUnion, value = value)
europe_mds.df$value <- europeanUnionTable$value[match(europe_mds.df$region,europeanUnionTable$country)]
ggplot() + geom_point(data = data.frame(as.matrix(europe_mds$points)) , mapping = aes(x = europe_mds$points[,1] , y = -europe_mds$points[,2]), 
              alpha = 0.5 , color = "blue", size = 5 ) + 
              labs(title = "figure3: MDS representation of pair-wise distances of European cities")
ggplot() + geom_polygon(data = europe_mds.df, aes(x = -long, y = lat, group = region, fill = value), colour = "black", size = 0.1)



# Add some data for each member

europeanUnionTable <- data.frame(country = europeanUnion, value = value)
europeCoords$value <- europeanUnionTable$value[match(europeCoords$region,europeanUnionTable$country)]
P <- ggplot() + geom_polygon(data = europeCoords, aes(x = long, y = lat, group = region, fill = value),
                             colour = "black", size = 0.1)



# Select only the index of states member of the E.U.
indEU <- which(worldMap$NAME%in%europeanUnion)
indEU <- which(as.character(worldMap$NAME) %in% europeancities)



ggplot() + geom_point(data = as.data.frame(cities_mds$conf) , mapping = aes(x = -D1 , y = -D2), 
              alpha = 0.5 , color = "blue", size = 10 ) + geom_text(data = as.data.frame(cities_mds$conf), 
              mapping = aes(x = -D1,y= -D2), label = rownames(cities) ) + 
              labs(title = "figure3: MDS representation of pair-wise distances of 11 US cities")

cities_mds

?smacof

cities_mds$conf[,1]
data.frame(as.matrix(cities_mds$confdist))