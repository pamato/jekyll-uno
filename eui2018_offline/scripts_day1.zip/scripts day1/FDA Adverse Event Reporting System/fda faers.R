
install.packages("rjson")
library("rjson")
library(RCurl)
library(plyr)
json_file_key <- "https://api.fda.gov/drug/event.json?api_key=TYuUFQW1r3LnENfvr6HIKn754fln3XfJgSj0w7ey&search=receivedate:[20040101+TO+20040131]&limit=100"
## above: limiting to January of 2004; limit searches of 100 results of output;
json_file <- "https://api.fda.gov/drug/event.json?search=receivedate:[19900101+TO+20041231]&limit=1&skip=0"
json <- fromJSON(getURL(json_file), method = "C")
json
names(json)

### FDA Adverse Event Reporting System ###

## 1990 to 2004 ##
j <- 0
faers90.04 <- data.frame()
#for (i in 1:205376){
for (i in 1:100){
  json_file <- paste("https://api.fda.gov/drug/event.json?search=receivedate:[19900101+TO+20041231]&limit=", i, "&skip=", j, sep="")
  json <- fromJSON(getURL(json_file), method = "C")
  # Header
  patient <- i
  companynumb <- json$results[[1]]$companynumb
  transmissiondateformat <- json$results[[1]]$transmissiondateformat
  receivedate <- json$results[[1]]$receivedate
  seriousnesshospitalization <- json$results[[1]]$seriousnesshospitalization
  serious <- json$results[[1]]$serious
  # Patient info
  patientonsetage <- json$results[[1]]$patient$patientonsetage
  patientonsetageunit <- json$results[[1]]$patient$patientonsetageunit
  patientsex <- json$results[[1]]$patient$patientsex
  ## Drug
  drugs <- data.frame(drugnum = 1:length(json$results[[1]]$patient$drug), drugcharacterization = NA, medicinalproduct = NA, drugstartdate = NA,
                      product_ndc=NA, nui = NA, package_ndc=NA, generic_name=NA, spl_set_id=NA, pharm_class_cs = NA, brand_name = NA,
                      manufacturer_name=NA, unii=NA, rxcui=NA, spl_id=NA, substance_name=NA, product_type=NA, route=NA, application_number=NA,
                      pharm_class_epc=NA, pharm_class_moa=NA, upc=NA, pharm_class_pe=NA, is_original_packager=NA, dosage_form=NA)
  for (k in 1:length(json$results[[1]]$patient$drug)){
    drugs$drugcharacterization[k] <- json$results[[1]]$patient$drug[[k]]$drugcharacterization
    drugs$medicinalproduct[k] <- json$results[[1]]$patient$drug[[k]]$medicinalproduct
    if (length(json$results[[1]]$patient$drug[[k]]$drugstartdate) > 0) {drugs$drugstartdate[k] <- json$results[[1]]$patient$drug[[k]]$drugstartdate}
    if (length(json$results[[1]]$patient$drug[[k]]$openfda) > 0){
      names.fda <- names(json$results[[1]]$patient$drug[[k]]$openfda)
      for (name in names.fda){drugs[[name]][k] <- paste(as.character(json$results[[1]]$patient$drug[[k]]$openfda[[name]]), collapse=";")}
    }
  }
  data <- cbind(patient, companynumb, transmissiondateformat, receivedate, seriousnesshospitalization, serious, patientonsetage, 
                patientonsetageunit, patientsex)
  data <- cbind(data, drugs)
  faers90.04 <- rbind.fill(faers90.04, data)
  j <- j + 1
}






















