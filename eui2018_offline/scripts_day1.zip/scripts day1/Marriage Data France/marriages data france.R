#######################################
# France Marriage Data 19th century   #
# Paulo Serodio                       #
# IPERG, Barcelona                    #
# 20/10/2017                          #
#######################################

# Packages

packages <- list("xml2","RCurl","rvest","plyr","XML","curl","httr","reshape2","progress","foreign")

## Install packages ##

for (pack in packages){
  install.packages(pack)
}


## Load Packages ##
lapply(packages, require, character.only=T)


# Function

trim <- function (x) gsub("^\\s+|\\s+$", "", x)

# Baseline information

browseURL("https://www.geneanet.org/releves-collaboratifs/geo/FRA/france?category=archives%23acte_registre")
base.url <- "https://www.geneanet.org/releves-collaboratifs/geo/FRA/france?category=archives%23acte_registre"
dep.name <- read_html(base.url) %>% html_nodes(xpath='//*[@id="content-wrapper"]/div[3]/ul[2]') %>% html_nodes("li") %>% html_text()
dep.commune.size <- gsub("\\s", "", gsub(".*\\((.*)\\).*", "\\1", dep.name))
dep.name <- gsub("(.*?)(\n.*)", "\\1", dep.name)
dep.url <- read_html(base.url) %>% html_nodes(xpath='//*[@id="content-wrapper"]/div[3]/ul[2]/li') %>% html_nodes("a") %>% html_attr("href")
data.matrix <- data.frame(cbind(dep.name, dep.commune.size, dep.url))
colnames(data.matrix) <- c("dep_name", "dep_commune_size", "dep_url")
data.matrix$dep_url <- as.character(data.matrix$dep_url)


# Track progress
pb <- progress_bar$new(format= " scraping [:bar] :percent\n",
                       total = nrow(data.matrix),
                       clear = FALSE, width= 60)

# Create data.frame with URLs containing marriage data
final.urls <- data.frame()
for (d in 1:nrow(data.matrix)){
    pb$tick()
    Sys.sleep(1 / 100)
    commune <- data.frame(department = data.matrix$dep_name[d],
                          commune_name = gsub("(.*?)(\n.*)", "\\1", read_html(data.matrix$dep_url[d]) %>% html_nodes(xpath='//*[@id="content-wrapper"]/div[3]/ul[2]') %>% html_nodes("li") %>% html_text()),
                          commune_url = read_html(data.matrix$dep_url[d]) %>% html_nodes(xpath='//*[@id="content-wrapper"]/div[3]/ul[2]/li') %>% html_nodes("a") %>% html_attr("href"),
                          commune_marriage = NA,
                          commune_marriage_url = NA)
    commune$commune_url <- as.character(commune$commune_url)
    for (c in 1:nrow(commune)){
        if ("Mariages" %in% trim(gsub("\n", "", read_html(commune$commune_url[c]) %>% html_nodes(".a-tooltip") %>% html_text()))){
          mariages.pos <- which(trim(gsub("\n", "", read_html(commune$commune_url[c]) %>% html_nodes(".a-tooltip") %>% html_text())) == "Mariages")
          etat.civil.records.url <- read_html(commune$commune_url[c]) %>% html_nodes(xpath='//*[@id="content-wrapper"]/div[3]/a') %>% html_attr("href")
          commune$commune_marriage_url[c] <- paste(as.character(etat.civil.records.url[mariages.pos]), collapse=", ")
          commune$commune_marriage[c] <- 1
        } else {commune$commune_marriage[c] <- 0}
    }
    final.urls <- rbind.fill(final.urls, subset(commune, commune_marriage==1))
}
# Some Communes have two or more 'Mariage' urls, so let's unpack them (leads to repeated Department-Commune pairs, but URLs are unique)
urls <- strsplit(as.character(final.urls$commune_marriage_url), ', ')
marriages.out <- data.frame(department=rep(final.urls$department, sapply(urls, FUN=length)), commune_name=rep(final.urls$commune_name, sapply(urls, FUN=length)),
                            commune_url=rep(final.urls$commune_url, sapply(urls, FUN=length)), commune_marriage=rep(final.urls$commune_marriage, sapply(urls, FUN=length)),
                            commune_marriage_url=unlist(urls))
# Output results to csv
write.csv(marriages.out, file="/Users/pauloserodio/Dropbox/IPERG/Web Scraping/France/marriages_urls.csv",
           row.names=FALSE)




