# web scraping demo not using any packages 

for(college in c("Brasenose", "Lincoln", "Oriel", "New", "Jesus", "Christchurch", "Corpus_Christi", "Worcester", "St_Hilda's")){
  
  url = paste0("http://en.wikipedia.org/wiki/", college, "_College,_Oxford") # assemble the URL
  cat("visiting", url, "\n")# report what we're doing
  download.file(url, destfile = "tmp.html", quiet = T)
  web_page = readChar("tmp.html", nchars = 100000) # read the file into the object "web_page"
  matches = regexpr("Undergraduates.+?\\d+<", web_page) #  
  first_matching_string = regmatches(web_page, matches)[1] # get the string of characters where the number of undergrads is reported
  number_of_undergrads = gsub("[^0-9]", "", first_matching_string)  # get the number from that string, by taking out everything that is not a number
  cat(college, "College has", number_of_undergrads, "undergraduates.\n") # report what we found
}