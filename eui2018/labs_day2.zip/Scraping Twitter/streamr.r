# the first time
rm(list=ls(all=TRUE))
getwd()
getwd()


library(twitteR)
library(ROAuth)
library(RCurl)

download.file(url="http://curl.haxx.se/ca/cacert.pem", destfile="cacert.pem")
## cacert.pem is a bundle of CA certificates that you use to verify that the server is really the correct 
## site you're talking to (when it presents its certificate in the SSL handshake). The bundle can be used by 
## tools like curl or wget, as well as other TLS/SSL speaking software. The bundle should contain the certificates 
## for the CAs you trust. This bundle is sometimes referred to as the "CA cert store".

requestURL <- "https://api.twitter.com/oauth/request_token"
accessURL <- "https://api.twitter.com/oauth/access_token"
authURL <- "https://api.twitter.com/oauth/authorize"

consumer_key <- "sCyhxl6x9xofzM3Q1M1ZnD4h1"
consumer_secret <- "iq4C8mfT95T1TSMsZtD1GeFr4gIaaHFqbHBoBc1wxPaz04HdtO"
access_token <- "572949103-ld6wMJGXN05CAes3XEI9PXlQPlf7J6jRE5F388Pl"
access_secret <- "T2tl765ks0vSwHakmQFOmzdpCDaZwJqIIoLhFbcdzZRMD"

# Bypass browser authentication -- insert PIN below;

my_oauth <- list(consumer_key = "sCyhxl6x9xofzM3Q1M1ZnD4h1",
   consumer_secret = "iq4C8mfT95T1TSMsZtD1GeFr4gIaaHFqbHBoBc1wxPaz04HdtO",
   access_token="572949103-ld6wMJGXN05CAes3XEI9PXlQPlf7J6jRE5F388Pl",
   access_token_secret = "T2tl765ks0vSwHakmQFOmzdpCDaZwJqIIoLhFbcdzZRMD")
my_oauth <- OAuthFactory$new(consumerKey = consumer_key, consumerSecret = consumer_secret, 
    requestURL = requestURL, accessURL = accessURL, authURL = authURL)
my_oauth$handshake(cainfo = system.file("CurlSSL", "cacert.pem", package = "RCurl"))
save(my_oauth, file = "my_oauth.Rdata")


# after the first time

rm(list=ls(all=TRUE))
getwd()
setwd("C:/Users/mw/Dropbox (VOICES)/TOPIC MODEL")
getwd()


library(streamR)
library(ROAuth)
library(RCurl)

load("my_oauth.Rdata")

# with streamR you capture via streaming the tweets
# filterStream opens a connection to the Streaming API that will return all tweets that contain one or more of the keywords given 
# in the track argument

# you can once again select the "language" if you want
# "timeout" is a numeric, maximum length of time (in seconds) of connection to stream. 
# The connection will be automatically closed after this period. 
# For example, setting timeout to 10800 will keep the connection open for 3 hours. 
# The default is 0, which will keep the connection open permanently.
# with the "follow" option, you can specify the string or numeric, vector of Twitter user IDs, 
# indicating the users whose public statuses should be delivered on the stream

# in the example below, I save the tweets in a database to which I could append further twitters later on

filterStream("tweetsTrump.json", track = c("Trump"), timeout = 30, 
  oauth = my_oauth)
# recover the tweets saved in your database
# If "simplify" is TRUE it will return a data frame with only tweet and user fields 
#(i.e., no geographic information or url entities).
tweets.df <- parseTweets("tweetsTrump.json")
# much more info than in twitteR!
str(tweets.df)
table(tweets.df$user_lang) # Language
tweets.df$location  # Location
sum(is.na(tweets.df$location)) 
sum(!is.na(tweets.df$location)) 
table(tweets.df$place_lat)
table(tweets.df$place_lon)
tweets.df$ time_zone 
mean(tweets.df $ followers_count)
hist(tweets.df $ followers_count)
summary(tweets.df $ followers_count)

# if you want to get the tweets from a specific location, you can, but different approach than twitteR
# you need to provide a vector of longitude, latitude pairs (with the southwest corner coming first) 
# specifying sets of bounding boxes to filter public statuses by
# how to do that? check here!
# http://boundingbox.klokantech.com/ and select "csv"
# in this example we want to download the tweets from Florence (i.e., all the tweets from Florence, given that track is NULL)

filterStream("tweetsIT.json", locations = c(11.220568,43.747138,11.296851,43.789216), timeout = 200, 
    oauth = my_oauth)
tweets.df <- parseTweets("tweetsIT.json", verbose = FALSE)
str(tweets.df)
tweets.df$place_lat
tweets.df$place_lon
table(tweets.df $ country_code)
tweets.df <- tweets.df[ which(tweets.df$country_code=='IT'), ]
table(tweets.df $ country_code)

# plot the results
library(ggplot2)
library(grid)
map.data <- map_data("world2", "japan")
points <- data.frame(x = tweets.df$lon, y = tweets.df$lat)
ggplot(map.data) + geom_map(aes(map_id = region), map = map.data, fill = "white",   
color = "grey20", size = 0.25) + expand_limits(x = map.data$long, y = map.data$lat) + 
    theme(axis.line = element_blank(), axis.text = element_blank(), axis.ticks = element_blank(), 
        axis.title = element_blank(), plot.margin = unit(0 * c(-1.5, -1.5, -1.5, -1.5), "lines")) + geom_point(data = points, 
    aes(x = x, y = y), size = 3, alpha = 1/3, color = "darkblue")


library(leaflet)
# plot your graph!
m <- leaflet(tweets.df)
m <- addTiles(m) # Add default OpenStreetMap map tiles
m <- addMarkers(m, lng=tweets.df$place_lon, lat=tweets.df$place_lat, popup=tweets.df$text)
m

# different style of graph

m <- leaflet(tweets.df)
m <- addTiles(m) # Add default OpenStreetMap map tiles
m <- addCircleMarkers(m, lng=tweets.df$place_lon, lat=tweets.df$place_lat, popup=tweets.df$text)
m

# a  lot of the markers are clumped together rather closely. 
# We can cluster them together by specifying clusterOptions as follows (zoom out and zoom in the graph!)
# The number inside each circle represents the total number of observations in that area. 
# Areas with higher observations  are marked by yellow circles and areas with lower incidents are marked by green circle

m <- leaflet(tweets.df)
m <- addTiles(m) # Add default OpenStreetMap map tiles
m <- addMarkers(m, lng=tweets.df$place_lon, lat=tweets.df$place_lat, clusterOptions = markerClusterOptions())
m

# plot your graph according to the time_zone

str(tweets.df)
table(newdata $ time_zone)
table(tweets.df$ time_zone)
tweets.df$ time_zone2 <- tweets.df$ time_zone
str(tweets.df)
tweets.df$time_zone2[is.na(tweets.df$time_zone2)] <- "other"
str(tweets.df)
table(tweets.df$ time_zone2)

newdata <- tweets.df[ which(tweets.df$ time_zone2=='Tokyo'), ]
str(newdata )

tweets.df$x <-  sapply(tweets.df$time_zone2, function(time_zone2) {
  if(time_zone2 == 'Tokyo') {
    "green"
   } else if(time_zone2 == 'Osaka') {
    "orange"
  } else {
    "red"
  } })

str(tweets.df)
table(tweets.df$x)

icons <- awesomeIcons(
  icon = 'ios-close',
  iconColor = 'black',
  library = 'ion',
  markerColor = tweets.df$x
)

m <- leaflet(tweets.df)
m <- addTiles(m) # Add default OpenStreetMap map tiles
m <- addAwesomeMarkers(m, lng=tweets.df$place_lon, lat=tweets.df$place_lat, popup=tweets.df$text, icon=icons)
m

# plot your graph according to followers_count (according to quartiles)
# change the value below according to the results of the collection of tweets!
# take the 1st Qu, Median, and 3rd Qu.

summary(tweets.df$ followers_count)

# same as
tweets.df$x3 <-  sapply(tweets.df$followers_count, function(followers_count) {
  if(followers_count <="1st Qu") {
    "green" 
} else if(followers_count<="Median" ) {
    "orange"
  }  else if(followers_count  <="3rd Qu") {
    "red"
  } else {
    "blue"
  } })
table(tweets.df$x3)

# different options for awesomeIcons: https://github.com/lvoogdt/Leaflet.awesome-markers
# you can also create your own Icons!!! check here: https://rstudio.github.io/leaflet/markers.html
icons <- awesomeIcons(
  icon = 'glass',
   iconColor = 'white',
  markerColor = tweets.df$x3
)

m <- leaflet(tweets.df)
m <- addTiles(m) # Add default OpenStreetMap map tiles
m <- addAwesomeMarkers(m, lng=tweets.df$place_lon, lat=tweets.df$place_lat, popup=tweets.df$text, icon=icons)
m

table(tweets.df$x3)