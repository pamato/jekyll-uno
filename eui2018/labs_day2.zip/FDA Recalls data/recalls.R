
### FDA recals since 2009 ###
setwd("/Users/pauloserodio/Dropbox/Oxford/Research Projects/FDA/data/Recalls")
xmlfile <- xmlParse("RecallsDataSet.xml")
xmltop <- xmlRoot(xmlfile)
recalls <- data.frame()
for (i in 1:xmlSize(xmltop)){
  prod_id <- i
  date <- xmlValue(xmlChildren(xmlChildren(xmltop)[[i]])$DATE)
  brand <- xmlValue(xmlChildren(xmlChildren(xmltop)[[i]])$BRAND_NAME)
  product <- xmlValue(xmlChildren(xmlChildren(xmltop)[[i]])$PRODUCT_DESCRIPTION)
  reason <- xmlValue(xmlChildren(xmlChildren(xmltop)[[i]])$REASON)
  company <- xmlValue(xmlChildren(xmlChildren(xmltop)[[i]])$COMPANY)
  comp_release <- xmlValue(xmlChildren(xmlChildren(xmltop)[[i]])$COMPANY_RELEASE_LINK)
  photos <- xmlValue(xmlChildren(xmlChildren(xmltop)[[i]])$PHOTOS_LINK)
  data <- cbind(prod_id, date, brand, product, reason, company, comp_release, photos)
  recalls <- rbind(recalls, data)
}



##############################################################
###                 FDA Enforcement Reports                ###
##############################################################


list.2004 <- as.list(c(120278:120330))
list.2005 <- as.list(c(120331:120382))
list.2006 <- as.list(c(120383:120434))
list.2007 <- as.list(c(120435:120486))
list.2008 <- as.list(c(120487:120538))
for (i in 2009:2012){
  url <- url(paste("http://www.fda.gov/Safety/Recalls/EnforcementReports/", i, "/default.htm", sep=""))
  htmlcode <- readLines(url)
  href <- which(grepl('/Safety/Recalls/EnforcementReports/ucm', htmlcode)==1) # Find position where href is
  list <- as.list(lapply(href, function(x) gsub("(.*ucm)(.*)(.htm.*)", "\\2", htmlcode[[x]])))
  listy <- paste("list.", i, sep="")
  assign(listy, list)
}
list.2012 <- list.2012[-c(1:2)]













