
devtools::install_github("ropensci/RSelenium")
require(RSelenium)
#RSelenium::rsDriver(javaargs = c("-Dwebdriver.chrome.driver=/Users/pauloserodio/Downloads/chromedriver"))

# Step 1 - run below in Terminal:
# java -jar selenium-server-standalone-x.xx.x.jar

rd <- rsDriver()
remDr <- rd[["client"]]
remDr$navigate("http://apps.webofknowledge.com/full_record.do?product=WOS&search_mode=AdvancedSearch&qid=1&SID=C4i7LdgaYawWjBjzgyp&page=1&doc=1")


## Departing from initial URL, get the following:

# Articles that cite original article:
citedby <- remDr$findElement('xpath', '//*[@id="sidebar-column1"]/div[1]/div[3]/div[1]/a')
citedby$sendKeysToElement(list("\uE007"))
url.cited <- citedby$getCurrentUrl()

# Further stats on original article:
stats <- remDr$findElement("xpath", '//*[@id="TCHideShow"]')
stats$sendKeysToElement(list("\uE007"))
url.stats <- stats$getCurrentUrl()

# Articles that original article is citing:
citing <- remDr$findElement('xpath', '//*[@id="sidebar-column1"]/div[1]/div[10]/a')
citing$sendKeysToElement(list("\uE007"))
url.citing <- citing$getCurrentUrl()

### Go to page
goto_page <- function(val) {
  remDr$findElements(using = 'class name', 
                   value = "fg-button")[[val]]$sendKeysToElement(list(key = "enter"))
}

### Find Table in page "Cited References"; for each reference, open page and scrape information (if URL available)

table <- remDr$findElement(using="css", value="#records_chunks > div.search-results")

### All results - from here create if function to check if element has hyperlink; 
# if yes, click and extract info; if not, extract what's available

## Article title
results.nhl <- table$findChildElements(using = "class", value="reference-title")
  for (l in 1:length(results.nhl)){
    results.nhl[[1]]$highlightElement()
    results.nhl[[l]]$sendKeysToElement(list("\uE007"))
  }
 

# Article title and journal hidden information

results.hl <- table$findChildElements(using = "class", value="smallV110")
for (k in 1:length(results.hl)){
  res1.url <- results.hl[[k]]$sendKeysToElement(list("\uE007"))
  page <- xml2::read_html(remDr$getPageSource()[[1]])
  # Saving page
  xml2::write_html(page, paste0("citedref_", l, ".html"))
  remDr$goBack()
}

