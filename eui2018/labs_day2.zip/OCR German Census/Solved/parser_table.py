# -*- coding: utf-8 -*-
"""
@author: pauloserodio
"""

import os
import math
import string
import numpy as np
from pdftabextract.common import read_xml, parse_pages
from pprint import pprint
from pdftabextract import imgproc
import cv2
import pandas as pd
from array import array
from math import radians, degrees
from pdftabextract.common import ROTATION, SKEW_X, SKEW_Y
from pdftabextract.geom import pt
from pdftabextract.textboxes import rotate_textboxes, deskew_textboxes
from pdftabextract.clustering import find_clusters_1d_break_dist
from pdftabextract.clustering import calc_cluster_centers_1d
from pdftabextract.clustering import zip_clusters_and_values
from pdftabextract.textboxes import border_positions_from_texts, split_texts_by_positions, join_texts
from pdftabextract.common import all_a_in_b, DIRECTION_VERTICAL
from pdftabextract.extract import make_grid_from_positions
from pdftabextract.extract import fit_texts_into_grid, datatable_to_dataframe
import re
from pdftabextract.common import save_page_grids

# Working directories
os.chdir("/Users/pauloserodio/Dropbox/IPERG/OCR/AbbyCloud/output-1910/pdf/right orientation")
DATAPATH = '/Users/pauloserodio/Dropbox/IPERG/OCR/AbbyCloud/output-1910/pdf/right orientation/'
OUTPUTPATH = '/Users/pauloserodio/Dropbox/IPERG/OCR/AbbyCloud/output-1910/pdf/right orientation/python_output/'
INPUT_XML = '200_outNormal.pdf.xml'

# Load the XML that was generated with 'pdftohtml' from poppler-utils:
# in terminal: pdftohtml -c -hidden -xml 200_outNormal.pdf 200_outNormal.pdf.xml
xmltree, xmlroot = read_xml(os.path.join(DATAPATH, INPUT_XML))

# parse it and generate a dict of pages
pages = parse_pages(xmlroot)
p_num = 1
p = pages[p_num]

# get the image file of the scanned page
imgfilebasename = p['image'][:p['image'].rindex('.')]
imgfile = os.path.join(DATAPATH, p['image'])

# create an image processing object with the scanned page
iproc_obj = imgproc.ImageProc(imgfile)

# calculate the scaling of the image file in relation to the text boxes coordinate system dimensions
page_scaling_x = iproc_obj.img_w / p['width']   # scaling in X-direction
page_scaling_y = iproc_obj.img_h / p['height']  # scaling in Y-direction

# detect the lines
lines_hough = iproc_obj.detect_lines(canny_kernel_size=3, canny_low_thresh=50, canny_high_thresh=150,
                                     hough_rho_res=1,
                                     hough_theta_res=np.pi/500,
                                     hough_votes_thresh=round(0.3 * iproc_obj.img_w))
print("> found %d lines" % len(lines_hough))

# helper function to save an image 
def save_image_w_lines(iproc_obj, imgfilebasename):
    img_lines = iproc_obj.draw_lines(orig_img_as_background=True)
    img_lines_file = os.path.join(OUTPUTPATH, '%s-lines-orig.png' % imgfilebasename)
    print("> saving image with detected lines to '%s'" % img_lines_file)
    cv2.imwrite(img_lines_file, img_lines)

save_image_w_lines(iproc_obj, imgfilebasename)


## If there any rotation or skews that need to be fixed

rot_or_skew_type, rot_or_skew_radians = iproc_obj.find_rotation_or_skew(radians(0.5),    # uses "lines_hough"
                                                                        radians(1),
                                                                        omit_on_rot_thresh=radians(0.5))
# rotate back or deskew text boxes
needs_fix = True
if rot_or_skew_type == ROTATION:
    print("> rotating back by %f°" % -degrees(rot_or_skew_radians))
    rotate_textboxes(p, -rot_or_skew_radians, pt(0, 0))
elif rot_or_skew_type in (SKEW_X, SKEW_Y):
    print("> deskewing in direction '%s' by %f°" % (rot_or_skew_type, -degrees(rot_or_skew_radians)))
    deskew_textboxes(p, -rot_or_skew_radians, rot_or_skew_type, pt(0, 0))
else:
    needs_fix = False
    print("> no page rotation / skew found")
if needs_fix:
    # rotate back or deskew detected lines
    lines_hough = iproc_obj.apply_found_rotation_or_skew(rot_or_skew_type, -rot_or_skew_radians)
    save_image_w_lines(iproc_obj, imgfilebasename + '-repaired')


### Detect Line Clusters (Columns)

MIN_COL_WIDTH = 50 # minimum width of a column in pixels, measured in the scanned pages

# cluster the detected *vertical* lines using find_clusters_1d_break_dist as simple clustering function
# (break on distance MIN_COL_WIDTH/2), remove all cluster sections that are considered empty

vertical_clusters = iproc_obj.find_clusters(imgproc.DIRECTION_VERTICAL, find_clusters_1d_break_dist,
                                            remove_empty_cluster_sections_use_texts=p['texts'], # use this page's textboxes
                                            remove_empty_cluster_sections_n_texts_ratio=0.30,    # 30% rule
                                            remove_empty_cluster_sections_scaling=page_scaling_x,  # the positions are in "scanned image space" -> we scale them to "text box space"
                                            dist_thresh=MIN_COL_WIDTH/2)
print("> found %d clusters" % len(vertical_clusters))

# draw the clusters
img_w_clusters = iproc_obj.draw_line_clusters(imgproc.DIRECTION_VERTICAL, vertical_clusters)
save_img_file = os.path.join(OUTPUTPATH, '%s-vertical-clusters.png' % imgfilebasename)
print("> saving image with detected vertical clusters to '%s'" % save_img_file)
cv2.imwrite(save_img_file, img_w_clusters)

## Calculate centers of the clusters, taking the median of the cluster values; need to divide by page scaling because 
#cluster positions are in image space, but we need the column positions in "text box space"

page_colpos = np.array(calc_cluster_centers_1d(vertical_clusters)) / page_scaling_x
print('found %d column borders:' % len(page_colpos))

## Calculate standard deviation of line clusters for each column line: 

def calc_cluster_std_1d(clusters_w_vals, method=np.std):
    """
    Calculate the cluster centers (for 1D clusters) using <method>.
    <clusters_w_vals> must be a sequence of tuples t where t[1] contains the values (as returned from
    zip_clusters_and_values).
    """
    return [method(vals) for _, vals in clusters_w_vals]				

## Get standard deviation for each line column				
page_colpos_stds = np.array(calc_cluster_std_1d(vertical_clusters)) / page_scaling_x

#########################################################
## Use column dividers to identify each subtable       ##
#########################################################

table_texts = {}
table_texts["tab1"] = [t for t in p['texts'] if t['left'] <= page_colpos[6]+page_colpos_stds[6]]
table_texts["tab2"] = [t for t in p['texts'] if t['left'] <= page_colpos[12]+page_colpos_stds[12]
							and t['left'] >=  page_colpos[6]-page_colpos_stds[6]]
table_texts["tab3"] = [t for t in p['texts'] if t['left'] <= page_colpos[18]+page_colpos_stds[18]
							and t['left'] >=  page_colpos[12]-page_colpos_stds[12]]	


# Check content for each set of tables							
for i in range(0, len(text_secondtab)):
    print(text_secondtab[i]['value'])

###############################################################
### Detecting row positions for each subtable 	          ###
### Extract and allocate data to each cell within subtables ###
###############################################################
### Fine line positions in each subtable;
### Find clusters: use median_text_height/2 to find gap bw clusters
### Calculate centre of Clusters
### Use centre of clusters ± median_text_height/2 to create range for [top]
### values per rows

for t in table_texts:
		median_text_height = np.median([r['height'] for r in table_texts[t]]) # Median text height in sub-table
		text_height_deviation_thresh = median_text_height / 2
		borders_y = border_positions_from_texts(table_texts[t], DIRECTION_VERTICAL)
		clusters_y = find_clusters_1d_break_dist(borders_y, dist_thresh=median_text_height/3)
		clusters_w_vals = zip_clusters_and_values(clusters_y, borders_y)
		pos_y = calc_cluster_centers_1d(clusters_w_vals)
		print('Number of rows found in', t, "=", len(pos_y))
		## Print out positions and ranges for each row:
		for i in range(0, len(pos_y)):
			if i < (len(pos_y)-1):
				print("Line", i, ":", "[", pos_y[i] - text_height_deviation_thresh,
						pos_y[i+1] - text_height_deviation_thresh, "]")
			else:
				print("Line", i, ":", "[", pos_y[i] - text_height_deviation_thresh)
		globals()[t] = pd.DataFrame(index=range(0,len(pos_y)), columns=['row_number','col1', 'col2', 'col3', 'col4', 'col5', 'col6'])
		for i in range(0, len(pos_y)):
			print(i)
			if i < (len(pos_y)-1):
				line = [r for r in table_texts[t] if r['top'] >= pos_y[i] - text_height_deviation_thresh
								and r['top'] < pos_y[i+1] - text_height_deviation_thresh]
			else: 
				line = [r for r in table_texts[t] if r['top'] >= pos_y[i] - text_height_deviation_thresh]
			for j in range(0, len(line)):
				globals()[t]['row_number'].iloc[i] = i
				if t == "tab1":
					n = 0
				elif t == "tab2":
					n = 6
				else:
					n = 12
				for col in globals()[t].drop('row_number', axis=1):
					if line[j]['left'] >= (page_colpos[n]-page_colpos_stds[n]) and line[j]['left'] <= (page_colpos[n+1]+page_colpos_stds[n+1]):
						if pd.isnull(globals()[t][col].iloc[i]):
							globals()[t][col].iloc[i] = line[j]['value']
						else: 
							globals()[t][col].iloc[i] = globals()[t][col].iloc[i] + ' || ' + line[j]['value']
					n = n+1

