library(abbyyR)
library(progress)
library(curl)


## Rename German Census individual pages

setwd("/Users/pauloserodio/Dropbox/Academic/Teaching/Summer Schools & Workshops/EUI Florence 2018/Course Main Folder/Lectures/Day 2/OCR German Census/")


## Set credentials

setapp(c("eui2018workshop", "NMr918vJwhOzs+LxtQIshi4W"))


## Start from Clean Slate

all_tasks <- listTasks(excludeDeleted = TRUE)
for (t in 1:nrow(all_tasks)){ 
  deleteTask(all_tasks$id[t])
}


## Submit all images to directory
path_to_img_dir <- "/Users/pauloserodio/Dropbox/Academic/Teaching/Summer Schools & Workshops/EUI Florence 2018/Course Main Folder/Lectures/Day 2/OCR German Census/input/"
total_files <- length(dir(path_to_img_dir))


# Iterate through files and submit all images
# Monitor progress

pb <- progress_bar$new(format= " uploading [:bar] :percent\n",
                       total = total_files,
                       clear = FALSE, width= 60)

# Abbyy Fine API does not keep file name, so we have to keep track of it locally
tracker <- data.frame(filename=NA, taskid=NA)


# Loop

j <- 1

for (i in dir(path_to_img_dir)){
    submit.image <- submitImage(file_path = paste0(path_to_img_dir, i))
    tracker[j,] <- c(gsub("(.*)(.pdf*)", "\\1", i), as.character(submit.image$id)) 
    j <- j + 1 
    # Progress bar
    pb$tick()
    Sys.sleep(2)
}


listTasks(excludeDeleted = TRUE)

# Process all files

submitted.files <- listTasks(excludeDeleted = TRUE)
for (i in 1:nrow(tracker)){ 
  processDocument(taskId = submitted.files$id[submitted.files$status=="Submitted"][i], textType=c("normal"), 
                correctOrientation = c("true"), correctSkew = c("true"), language="German",
                exportFormat = "pdfSearchable")
}



# Check if all tasks are finished

i <- 1

while(i < total_files){
    i <- nrow(listFinishedTasks())
    if (i == total_files){
        print("All Done!")
        break;
    }

    Sys.sleep(20)
}

## Download all results

setwd("/Users/pauloserodio/Dropbox/Academic/Teaching/Summer Schools & Workshops/EUI Florence 2018/Course Main Folder/Lectures/Day 2/OCR German Census/output/")

finishedlist <- listTasks(excludeDeleted = TRUE)
finishedlist$id <- as.character(finishedlist$id)
results <- merge(tracker, finishedlist, by.x="taskid", by.y="id")
names(results)
results$resultUrl <- as.character(results$resultUrl)

for(i in 1:nrow(results)){
    curl_download(results$resultUrl[i], destfile=paste0(results$filename[i], "_outNormal.pdf"), handle = new_handle())
}

############### Convert to XML ###############


### Separate pdf pages ###
# Run in Terminal
# cd /Users/pauloserodio/Dropbox/Academic/Teaching/Summer\ Schools\ \&\ Workshops/EUI\ Florence\ 2018/Course\ Main\ Folder/Lectures/Day\ 2/OCR\ German\ Census/output/
# for f in *.pdf; do  pdftohtml -c -hidden -xml $f $f.xml; done
# cd /Users/pauloserodio/Dropbox/Academic/Teaching/Summer\ Schools\ \&\ Workshops/EUI\ Florence\ 2018/Course\ Main\ Folder/Lectures/Day\ 2/OCR\ German\ Census/solved/ 
# python3 -m http.server 8080 --bind 127.0.0.1
browseURL("http://127.0.0.1:8080")


