###################################
####### Early Day Motions #########
###################################

library(xml2)
library(RCurl)
library(XML)
library(httr)

#### Get EDMs webpage number and summary information ####

data <- NULL

for (i in 0:1){
    url <- GET(paste("http://lda.data.parliament.uk/edms.xml?_view=EDMs+List&_pageSize=100&_page=", i, sep=""))
    #url <- paste("http://lda.data.parliament.uk/edms.xml?_view=EDMs+List&_pageSize=100&_page=", i, sep="")
    xmlfile <- xmlTreeParse(url, useInternalNodes = TRUE)
    xmltop <- xmlRoot(xmlfile)
   # str(xmlChildren(xmltop))
   #  xmlSize(xmlChildren(xmltop)$items) #number of nodes in each child
   # xmlSApply(xmlChildren(xmltop)$items, xmlName) #name(s)
   #  xmlSApply(xmlChildren(xmltop)$items, xmlAttrs) #attribute(s)
   # xmlSApply(xmlChildren(xmltop)$items, xmlSize) #size
   # #xmlSize(xmlChildren(xmlChildren(xmltop)$items)) # Number of EDMs in page
    for (k in 1:xmlSize(xmlChildren(xmlChildren(xmltop)$items))){
      page.data <- data.frame(date = xmlToList(xmlChildren(xmlChildren(xmlChildren(xmltop)$items)[k]$item)$dateTabled)$text,
                    edm_number = xmlToList(xmlChildren(xmlChildren(xmlChildren(xmltop)$items)[k]$item)$edmNumber),
                    edm_status = xmlToList(xmlChildren(xmlChildren(xmlChildren(xmltop)$items)[k]$item)$edmStatus),
                    signatures = xmlToList(xmlChildren(xmlChildren(xmlChildren(xmltop)$items)[k]$item)$numberOfSignatures)$text,
                    session = xmlToList(xmlChildren(xmlChildren(xmlChildren(xmltop)$items)[k]$item)$session)$item,
                    session_number = paste(xmlToList(xmlChildren(xmlChildren(xmlChildren(xmltop)$items)[k]$item)$sessionNumber), collapse=","),
                    title = xmlToList(xmlChildren(xmlChildren(xmlChildren(xmltop)$items)[k]$item)$title),
                    webpage_number = gsub("(.*resources/)(.*)","\\2",  as.character(xmlAttrs(xmlChildren(xmlChildren(xmltop)$items)[k]$item))))
      if (length(xmlChildren(xmlChildren(xmlChildren(xmltop)$items)[k]$item)$sponsorPrinted) > 0){
          page.data$sponsors <- paste(sapply(1:xmlSize(xmlToList(xmlChildren(xmlChildren(xmlChildren(xmltop)$items)[k]$item)$sponsorPrinted)), function(x)
                      xmlToList(xmlChildren(xmlChildren(xmlChildren(xmltop)$items)[k]$item)$sponsorPrinted)[x]$item), collapse=",")
      } else {page.data$sponsors <- NA}
      if(length(xmlChildren(xmlChildren(xmlChildren(xmltop)$items)[k]$item)$primarySponsorPrinted) > 0){
          page.data$primary_sponsor  <- paste( xmlToList( xmlChildren(   xmlChildren(xmlChildren(xmltop)$items)[k]$item)$primarySponsorPrinted ), collapse=",")
      } else {page.data$primary_sponsor <- NA}
      data <- rbind(data, page.data)
    }
}
rm(list=setdiff(ls(), "data"))

#### Get EDMs full text + information on sponsors ####

edm.data <- NULL
browseURL("http://explore.data.parliament.uk/?endpoint=edms/")
for (w in 1:length(data$webpage_number)){
    #url <- GET(paste("http://lda.data.parliament.uk/edms/", w, ".xml", sep=""))
    url <- GET(paste("http://lda.data.parliament.uk/edms/", as.character(data$webpage_number[w]), ".xml", sep=""))
    xmlfile <- xmlTreeParse(url, useInternalNodes = TRUE)
    xmltop <- xmlRoot(xmlfile)
      edm.temp <- data.frame(
          date = xmlToList(xmlChildren(xmlChildren(xmltop)$primaryTopic)$dateTabled)$text,
          edm_number = xmlToList(xmlChildren(xmlChildren(xmltop)$primaryTopic)$edmNumber),
          status = xmlToList(xmlChildren(xmlChildren(xmltop)$primaryTopic)$edmStatus),
          motion_text = xmlToList(xmlChildren(xmlChildren(xmltop)$primaryTopic)$motionText),
          number_signatures = xmlToList(xmlChildren(xmlChildren(xmltop)$primaryTopic)$numberOfSignatures)$text,
          primary_sponsor = paste(xmlToList(xmlChildren(xmlChildren(xmltop)$primaryTopic)$primarySponsorPrinted),collapse=","),
          session = xmlToList(xmlChildren(xmlChildren(xmltop)$primaryTopic)$session)$item,
          session_number = paste(xmlToList(xmlChildren(xmlChildren(xmltop)$primaryTopic)$sessionNumber), collapse=","),
          title = xmlToList(xmlChildren(xmlChildren(xmltop)$primaryTopic)$title),
          type = gsub("(.*#)(.*)", "\\2", xmlToList(xmlChildren(xmlChildren(xmltop)$primaryTopic)$type))
        )
      if(length(xmlChildren(xmlChildren(xmltop)$primaryTopic)$sponsorPrinted) > 0){
        edm.temp$sponsors <- paste(xmlToList(xmlChildren(xmlChildren(xmltop)$primaryTopic)$sponsorPrinted), collapse=";")
      } else {edm.temp$sponsors <- NA }
      edm.temp <- edm.temp[rep(nrow(edm.temp), each=xmlSize(xmlChildren(xmlChildren(xmlChildren(xmltop)$primaryTopic)$signature))),]
      signatoire <- NULL
      for (s in 1:xmlSize(xmlChildren(xmlChildren(xmlChildren(xmltop)$primaryTopic)$signature))){
          signatoire.temp <- data.frame(
               constituency = xmlToList(xmlChildren(xmlChildren(xmlChildren(xmlChildren(xmltop)$primaryTopic)$signature)[s]$item)$constituency),
               date_signed = xmlToList(xmlChildren(xmlChildren(xmlChildren(xmlChildren(xmltop)$primaryTopic)$signature)[s]$item)$dateSigned)$text,
               member_name =  xmlToList(xmlChildren(xmlChildren(xmlChildren(xmlChildren(xmltop)$primaryTopic)$signature)[s]$item)$memberPrinted),
               party = xmlToList(xmlChildren(xmlChildren(xmlChildren(xmlChildren(xmltop)$primaryTopic)$signature)[s]$item)$party)
          )
          if("href" %in% names(xmlToList(xmlChildren(xmlChildren(xmlChildren(xmlChildren(xmltop)$primaryTopic)$signature)[s]$item)$member)$item)){
               signatoire.temp$member_id <- gsub("(.*members/)(.*)", "\\2",as.character(xmlToList(xmlChildren(xmlChildren(xmlChildren(xmlChildren(xmltop)$primaryTopic)$signature)[s]$item)$member)$item))  
               } else { signatoire.temp$member_id = gsub("(.*members/)(.*)", "\\2", as.character( xmlToList(xmlChildren(xmlChildren(xmlChildren(xmlChildren(xmltop)$primaryTopic)$signature)[s]$item)$member)$item $.attrs ))}
              
          if(length(xmlChildren(xmlChildren(xmlChildren(xmlChildren(xmltop)$primaryTopic)$signature)[s]$item)$order) > 0){
            signatoire.temp$order_signed <- xmlToList(xmlChildren(xmlChildren(xmlChildren(xmlChildren(xmltop)$primaryTopic)$signature)[s]$item)$order)$text
          } else { signatoire.temp$order_signed <- NA}
          signatoire <- rbind(signatoire, signatoire.temp)
      }
    edm.temp.bound <- cbind(edm.temp, signatoire)
    edm.data <- rbind(edm.temp.bound, edm.data)
}
  

###################
### Alternative ###
###################

source <- data.frame(session=c("1989-90","1990-91","1991-92","1992-93","1993-94","1994-95","1995-96","1996-97","1997-98","1998-99",
                               "1999-00","2000-01","2001-02","2002-03","2003-04","2004-05","2005-06","2006-07","2007-08","2008-09",
                               "2009-10","2010-12","2012-13","2013-14","2014-15", "2015-16"),
                     pages=c(37,33,22,62,40,36,28,16,40,23,28,15,43,45,43,22,63,47,54,48,26,62,26,26,18,28))
source$session <- as.character(source$session)

final.data <- NULL
for (i in source$session){
  data <- NULL
  for (j in 0:source$page[source$session==i]){
    u <- paste("http://www.parliament.uk/business/publications/business-papers/commons/early-day-motions/edms-by-number/?orderby=&session=", i, sep="")
    u <- paste(u, "&page=", j, sep="")
    url <- read_html(u)
    table <- data.frame(url %>% html_nodes(xpath='//*[@id="number-list"]') %>% html_table())
    data <- rbind(data, table)
  }
  colnames(data) <- c("edm", "title", "sponsor", "signatures")
  data$edm <- gsub("(.*motion )(.*)", "\\2", data$edm)
  data$session <- i
  final.data <- rbind(final.data, data)
}
assertthat::are_equal(nrow(final.data), 47236) ## Check if we recovered all Early Day Motions since 1989.
final.data$amendment <- 0
final.data$amendment[grep("Amendment", final.data$edm)] <- 1

